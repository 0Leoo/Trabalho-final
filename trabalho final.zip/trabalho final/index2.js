
var valor_compra
var saldo = 400

alert("Olá novamente, está é a cauculadora. Aqui você poderá saber quanto irá gastar antes de realizar a compra")

valor_compra = prompt("-Diga qual é o valor da(s) compra(s)-")

alert(`-Pelos meus cauculos seu saldo final será de ${400 - valor_compra}`)