
var seu_nome

alert ('Olá, bem vindo(a) a Magic Garden!')
alert('Meu nome é Hiu, sou vice dono dessa loja')
seu_nome = prompt('Qual seu nome ?')
alert(`Ah!, então você é ${seu_nome}, meu superior me avisou que você viria.
         Bem, antes de você ir ver os produtos da loja, meu 
            superior me disse para eu te dar isso...`)
  alert('-VOCÊ RECEBEU UM TICKET DE COMPRA GRATUITA-')
  alert('-Esse TICKET DE COMPRA GRATUITA pode ser usado em 3 produtos da sua escolha-')
  alert('Agora pode ir fazer suas compras :)')
alert('-Você tem R$400,00 reais no momento-')


